import React from "react";
import { MASLOL_OPTIONS, CONTINUATION_TRUE_LABEL, CONTINUATION_FALSE_LABEL, CONTINUATION_LABEL } from "../../../utils/Dec";
import "./ProjectMetadata.css";

function getMaslolLabel(maslol) {
  return MASLOL_OPTIONS.find((o) => o.value === maslol)?.label || maslol || "—";
}

function getContinuationLabel(isHemshechi) {
  const isContinuation = Boolean(isHemshechi);
  return `${CONTINUATION_LABEL}: ${isContinuation ? CONTINUATION_TRUE_LABEL : CONTINUATION_FALSE_LABEL}`;
}

export function buildProjectMetaRows(project) {
  return [
    [
      { label: 'אגף:', value: project.agaffName },
      { label: 'מבוצע ע\'י:', value: project.tsevetMevatseaName },
    ],
    [
      { label: 'המשכי:', value: getContinuationLabel(project.logHemsheci) },
      { label: 'מסלול:', value: getMaslolLabel(project.maslol) },
    ],
  ];
}

export function ProjectMetaSection({ rows }) {
  return (
    <div className="project-meta-section">
      {rows.map((row, rowIndex) => (
        <div className="project-meta-row" key={rowIndex}>
          {row.map((item, itemIndex) => (
            <div key={`${rowIndex}-${itemIndex}`} className="project-meta-item">
              <span className="project-meta-label">{item.label}</span>
              <span className="project-meta-value">
                {item.value || "—"}
              </span>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}
