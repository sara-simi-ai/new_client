import React from "react";
import { CONTINUATION_TRUE_LABEL, CONTINUATION_FALSE_LABEL, MASLOL_OPTIONS } from "../../../utils/Dec";

export const isRealText = (value) => {
  const normalized = String(value || "").trim().toLowerCase();
  return normalized !== "" && normalized !== "string";
};

export const getOptionLabel = (options, value, fallback = "לא ידוע") =>
  options.find((item) => item.value === value)?.label || fallback;

export function buildProjectMetaRows(project) {
  return [
    [
      { label: `${AGAF_LABEL} :`, value: project.agaffName },
      { label: `${TSEVET_MEVATSEA_LABEL} :`, value: project.tsevetMevatseaName },
    ],
    [
      {
        label: `${CONTINUATION_LABEL} :`,
        value: project.logHemsheci ? CONTINUATION_TRUE_LABEL : CONTINUATION_FALSE_LABEL,
      },
      {
        label: `${MASLOL_LABEL} :`,
        value: getOptionLabel(MASLOL_OPTIONS, project.maslol),
      },
    ],
  ];
}

export function ProjectMetaSection({ rows }) {
  return (
    <div className="card-meta-section">
      {rows.map((row, rowIndex) => (
        <div className="card-meta-row" key={rowIndex}>
          {row.map((item, itemIndex) => (
            <span className="card-meta-item" key={`${rowIndex}-${itemIndex}`}>
              <span className="card-meta-label">{item.label}</span>
              <span className="card-meta-value">{item.value || "—"}</span>
            </span>
          ))}
        </div>
      ))}
    </div>
  );
}


export default {
  isRealText,
  getOptionLabel,
  buildProjectMetaRows,
  ProjectMetaSection,
};
